# With regular docstrings
def complex(real=0.0, imag=0.0):
    """Form a complex number.

    Keyword arguments:
    real -- the real part (default 0.0)
    imag -- the imaginary part (default 0.0)

    Some more description text, artificially
    lengthened to make it span two lines.

    Another paragraph.
    """
    pass
