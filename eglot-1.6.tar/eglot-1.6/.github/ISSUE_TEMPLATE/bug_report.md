---
name: Bug report
about: Create a report to help us improve Eglot
title: ''
labels: ''
assignees: ''

---

Before submitting an issue, please, read our guidelines
on reporting bugs here:
https://github.com/joaotavora/eglot#reporting-bugs
