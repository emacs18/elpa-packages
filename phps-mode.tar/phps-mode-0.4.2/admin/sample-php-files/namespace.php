<?php

namespace MyNameSpace;

function myNamespacedFunction() {
    echo 'here';
}

class MyClass {
    public function myFunction()
    {
        echo "Do something here";
    }
}

class MyClass2 {

}
