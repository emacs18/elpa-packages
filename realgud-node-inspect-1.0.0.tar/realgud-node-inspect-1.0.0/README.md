Module to add [node inspect](https://nodejs.org/api/debugger.html)'s [V8-inspector-protocol](https://chromedevtools.github.io/devtools-protocol/v8/Debugger)
debugger support to emacs
[realgud](http://github.com/realgud/realgud).

Note: for node before version 6.3, an older protocol is used.  In realgud,
that debugger for the older version is called `node-debug`.
