Emacs Lisp Module to add [ipdb](https://pypi.org/project/ipdb/) support to [realgud](http://github.com/rocky/emacs-dbgr).
