Provides realgud support for the Java's jdb debugger.
See https://docs.oracle.com/javase/7/docs/technotes/tools/windows/jdb.html
