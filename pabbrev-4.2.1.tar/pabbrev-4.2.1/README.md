Predictive Abbreviation Expansion for Emacs
===========================================

Provides predictive abbreviation expansion with no configuration, working with
any mode. For more details see pabbrev.el




## Releases

### 4.0

This release provides better key handling, meaning expansion is configurable.

The code base is now in its own repository, so that I can tag it.
