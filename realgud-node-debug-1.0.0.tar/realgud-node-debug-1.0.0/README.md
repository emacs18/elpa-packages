Module to add the older [node
debug]( https://nodejs.org/dist/latest-v6.x/docs/api/debugger.html) debugger support to emacs
[realgud](http://github.com/realgud/realgud). This protocol was used up until version 6.3 and
deprecated in node version 8.

For node before after 6.3, use [realgud-node-inspect]. (http://github.com/realgud/realgud-node-inspect).
