This is a "storage" package used by completion engines such as `company-math.el` and `ac-math.el`.

Defined (a)lists are:

 `math-symbol-list-basic`
 `math-symbol-list-extended`
 `math-symbol-list-packages`
 `math-symbol-list-latex-commands`


## Known packages that use these lists

  - [company-math](https://github.com/vspinu/company-math)
  - [ac-math](https://github.com/vspinu/ac-math)
  - [unicode-math-input](https://github.com/tpapp/unicode-math-input)
