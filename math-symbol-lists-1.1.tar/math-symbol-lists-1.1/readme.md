This is a "storage" package used by completion engines such as `company-math.el` and `ac-math.el`.

Defined (a)lists are: `math-symbol-list-basic`, `math-symbol-list-extended`,
`math-symbol-list-latex-commands`.
