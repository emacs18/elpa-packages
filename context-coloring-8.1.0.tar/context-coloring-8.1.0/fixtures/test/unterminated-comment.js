function a() {
    /*
    function b() {

    }
}
