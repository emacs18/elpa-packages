(function () {
    if (1) {
        var a;
        let b;
        const c;
    }
}());
