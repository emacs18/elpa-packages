var a = function () {};
function b() {
    var c = function () {};
    function d() {}
}
