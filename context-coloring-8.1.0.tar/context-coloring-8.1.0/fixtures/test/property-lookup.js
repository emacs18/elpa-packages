(function () {
    window.foo();
    window. bar();
    window.foo.bar();
}());
