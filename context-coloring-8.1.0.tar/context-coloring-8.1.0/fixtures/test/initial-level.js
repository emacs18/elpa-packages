
var a = global('a');
