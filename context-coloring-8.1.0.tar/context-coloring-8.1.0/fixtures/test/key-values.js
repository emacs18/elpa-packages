(function () {
    var a;
    (function () {
        return {
            b: a
        };
    }());
}());
