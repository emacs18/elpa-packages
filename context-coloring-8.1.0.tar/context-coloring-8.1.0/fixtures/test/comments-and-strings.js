void 0;
// Foo.
/* Bar. */
'use strict';
