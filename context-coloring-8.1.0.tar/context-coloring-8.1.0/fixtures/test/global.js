(function () {
    var a = global('a');
}());
