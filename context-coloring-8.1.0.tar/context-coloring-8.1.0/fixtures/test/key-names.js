(function () {
    return {
        a: 0,
        b : 2
    };
}());
