(function () {
    try {} catch (e) {
        var a = e;
        try {} catch (e) {
            var a = e;
        }
    }
}());
