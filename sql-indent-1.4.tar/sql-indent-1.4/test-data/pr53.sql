select my_col || chr(10)
    || '-*-' data_type,
       x
from dual;


-- Local Variables:
-- mode: sql
-- mode: sqlind-minor
-- tab-width: 2
-- indent-tabs-mode: nil
-- sql-product: oracle
-- End:

